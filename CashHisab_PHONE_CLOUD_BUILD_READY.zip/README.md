# CashHisab — MVP v5

## Fixed/implemented
- Local phone storage for accounts and transactions.
- Custom accounts + Investment.
- Account Transfer UI: transfer between any two accounts; creates matching outgoing/incoming entries.
- Transaction Edit.
- Transaction Delete.
- Full report PDF + separate PDF per account.
- PDF preview + share/download.
- Backup ZIP contains JSON data + PDFs.
- Google Drive backup architecture with nightly WorkManager scheduling.
- Drive connection uses Google's authorization flow.

## Next
- Replace current preferences storage with Room database migration.
- True backup restore/import from Google Drive/ZIP.
- Monthly/weekly/yearly analytics + charts.
- Budget and alerts.
- Customer/Due ledger.
- Backup version/history management.
- PIN/fingerprint lock.
- Final UI, testing, and signed APK.

## Google Drive
Before real Drive backup works, configure Google Cloud OAuth for the final package name and signing certificate SHA-1, enable Drive API, and configure the consent screen.
