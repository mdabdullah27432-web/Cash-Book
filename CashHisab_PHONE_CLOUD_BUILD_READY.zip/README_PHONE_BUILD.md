# CashHisab — phone-only APK build

This project includes a GitHub Actions workflow so the APK can be built in the cloud without a PC/laptop.

1. On your phone, create a GitHub account and a NEW repository named `CashHisab`.
2. Upload all files/folders from this project to the repository. Keep `.github/workflows/build-apk.yml` exactly at that path.
3. Open the repository > Actions > `Build CashHisab APK`.
4. Tap `Run workflow` (or push to `main` and it will run automatically).
5. Wait for the job to finish successfully.
6. Open the completed workflow run. Under `Artifacts`, download `CashHisab-debug-apk`.
7. Extract the downloaded artifact and install the `.apk` on the phone.

No Google password or Drive token should be put into source code. Google Drive OAuth configuration is a later setup step.
