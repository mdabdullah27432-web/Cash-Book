package com.example.cashhisab

import android.app.*
import android.content.*
import androidx.activity.result.IntentSenderRequest
import androidx.compose.ui.platform.LocalContext
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.*
import android.os.ParcelFileDescriptor
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.work.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.Scopes
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class TxType { INCOME, EXPENSE }

data class Transaction(
    val id: Long, val type: TxType, val amount: Double,
    val category: String, val account: String, val note: String, val time: Long,
    val transferId: Long? = null
)

class MainActivity : ComponentActivity() {
    private lateinit var store: LocalStore
    private val authLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            try {
                val auth = Identity.getAuthorizationClient(this)
                    .getAuthorizationResultFromIntent(result.data)
                auth.accessToken?.let {
                    getSharedPreferences("cash_hisab", MODE_PRIVATE)
                        .edit().putBoolean("drive_connected", true).apply()
                }
            } catch (_: Exception) {}
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LocalStore(this)
        BackupScheduler.schedule(this)
        setContent {
            CashHisabApp(
                context = this,
                onConnectDrive = { connectDrive() }
            )
        }
    }

    private fun connectDrive() {
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scopes.DRIVE_FILE))
            .build()
        Identity.getAuthorizationClient(this).authorize(request)
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    authLauncher.launch(
                        IntentSenderRequest(result.pendingIntent!!.intentSender)
                    )
                } else {
                    getSharedPreferences("cash_hisab", MODE_PRIVATE)
                        .edit().putBoolean("drive_connected", true).apply()
                }
            }
    }
}

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("cash_hisab", Context.MODE_PRIVATE)
    fun accounts(): List<String> {
        val raw = prefs.getString("accounts", null) ?: return listOf("Cash","Bank","MFS","Investment")
        return runCatching { val a=JSONArray(raw); (0 until a.length()).map{a.getString(it)} }
            .getOrDefault(listOf("Cash","Bank","MFS","Investment"))
    }
    fun saveAccounts(v: List<String>) { prefs.edit().putString("accounts", JSONArray(v).toString()).apply() }
    fun transactions(): List<Transaction> {
        val raw=prefs.getString("transactions",null) ?: return emptyList()
        return runCatching {
            val a=JSONArray(raw); (0 until a.length()).map { i ->
                val o=a.getJSONObject(i)
                Transaction(o.getLong("id"),TxType.valueOf(o.getString("type")),o.getDouble("amount"),
                    o.getString("category"),o.getString("account"),o.getString("note"),o.getLong("time"),
                    if (o.has("transferId") && !o.isNull("transferId")) o.getLong("transferId") else null)
            }.sortedByDescending{it.time}
        }.getOrDefault(emptyList())
    }
    fun saveTransactions(v: List<Transaction>) {
        val a=JSONArray(); v.forEach{a.put(JSONObject().apply{
            put("id",it.id);put("type",it.type.name);put("amount",it.amount);put("category",it.category)
            put("account",it.account);put("note",it.note);put("time",it.time)
            it.transferId?.let { id -> put("transferId", id) }
        })}; prefs.edit().putString("transactions",a.toString()).apply()
    }
    fun exportJson(): String {
        val o=JSONObject()
        o.put("backupTime",System.currentTimeMillis())
        o.put("accounts",JSONArray(accounts()))
        val tx=JSONArray(); transactions().forEach{tx.put(JSONObject().apply{
            put("id",it.id);put("type",it.type.name);put("amount",it.amount);put("category",it.category)
            put("account",it.account);put("note",it.note);put("time",it.time)
            it.transferId?.let { id -> put("transferId", id) }
        })}; o.put("transactions",tx); return o.toString(2)
    }
}


object BackupBundle {
    fun create(context: Context, store: LocalStore): File {
        val dir = File(context.filesDir, "backups").apply { mkdirs() }
        val file = File(dir, "cash_hisab_backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.zip")
        val reports = PdfReports.createAll(context, store)
        java.util.zip.ZipOutputStream(FileOutputStream(file)).use { zip ->
            val json = store.exportJson().toByteArray(Charsets.UTF_8)
            zip.putNextEntry(java.util.zip.ZipEntry("cash_hisab_data.json"))
            zip.write(json)
            zip.closeEntry()
            reports.forEach { pdf ->
                zip.putNextEntry(java.util.zip.ZipEntry("reports/${pdf.name}"))
                pdf.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        return file
    }
}

object PdfReports {
    fun createAll(context: Context, store: LocalStore): List<File> {
        val dir=File(context.filesDir,"reports").apply{mkdirs()}
        val tx=store.transactions()
        val out=mutableListOf<File>()
        out += createPdf(File(dir,"cash_hisab_full_report.pdf"),"Cash হিসাব — Full Report",tx)
        store.accounts().forEach { account ->
            out += createPdf(File(dir,"account_${safe(account)}.pdf"),"Account: $account",
                tx.filter{it.account==account})
        }
        return out
    }

    fun createPdf(file: File, title: String, tx: List<Transaction>): File {
        val doc=android.graphics.pdf.PdfDocument()
        val pageW=595; val pageH=842
        var pageNum=1; var page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW,pageH,pageNum).create())
        var canvas=page.canvas; val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.typeface=Typeface.create("sans",Typeface.BOLD); paint.textSize=20f
        var y=45f; canvas.drawText(title,35f,y,paint)
        paint.typeface=Typeface.create("sans",Typeface.NORMAL); paint.textSize=11f; y+=28
        val income=tx.filter{it.type==TxType.INCOME}.sumOf{it.amount}
        val expense=tx.filter{it.type==TxType.EXPENSE}.sumOf{it.amount}
        canvas.drawText("Income: ${money(income)}    Expense: ${money(expense)}    Net: ${money(income-expense)}",35f,y,paint); y+=25
        tx.forEachIndexed { idx,t ->
            if(y>805){
                doc.finishPage(page); pageNum++; page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW,pageH,pageNum).create())
                canvas=page.canvas; y=45f
            }
            val sign=if(t.type==TxType.INCOME) "+" else "-"
            canvas.drawText("${dateText(t.time)}  |  ${t.account}  |  ${t.category}  |  $sign${money(t.amount)}",35f,y,paint)
            y+=17
            if(t.note.isNotBlank()){canvas.drawText("Note: ${t.note.take(75)}",55f,y,paint);y+=16}
        }
        doc.finishPage(page)
        FileOutputStream(file).use{doc.writeTo(it)}
        doc.close(); return file
    }
    private fun safe(s:String)=s.replace(Regex("[^A-Za-z0-9_-]"),"_")
}

object BackupScheduler {
    private const val NAME="nightly_drive_backup"
    fun schedule(context: Context) {
        val now=Calendar.getInstance()
        val next=Calendar.getInstance().apply{
            set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,5);set(Calendar.MILLISECOND,0)
            if(!after(now)) add(Calendar.DAY_OF_YEAR,1)
        }
        val delay=next.timeInMillis-System.currentTimeMillis()
        val req=OneTimeWorkRequestBuilder<DriveBackupWorker>()
            .setInitialDelay(delay,TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(NAME,ExistingWorkPolicy.REPLACE,req)
    }
}

class DriveBackupWorker(appContext: Context, params: WorkerParameters): Worker(appContext,params) {
    override fun doWork(): Result {
        val store=LocalStore(applicationContext)
        val prefs=applicationContext.getSharedPreferences("cash_hisab",Context.MODE_PRIVATE)
        val connected=prefs.getBoolean("drive_connected",false)
        if(!connected) { BackupScheduler.schedule(applicationContext); return Result.success() }
        return try {
            val authReq=AuthorizationRequest.builder()
                .setRequestedScopes(listOf(Scopes.DRIVE_FILE)).build()
            val result=com.google.android.gms.auth.api.identity.Identity
                .getAuthorizationClient(applicationContext).authorize(authReq)
                .result
            val token=result.accessToken ?: run { BackupScheduler.schedule(applicationContext); return Result.success() }
            val backup = BackupBundle.create(applicationContext, store)
            val body = backup.readBytes()
            DriveUploader.upload(applicationContext,token,body,backup.name,"application/zip")
            BackupScheduler.schedule(applicationContext)
            Result.success()
        } catch (_: Exception) {
            BackupScheduler.schedule(applicationContext)
            Result.retry()
        }
    }
}

object DriveUploader {
    fun upload(context: Context, token: String, data: ByteArray, name: String, mime: String) {
        val boundary="----CashHisab${System.currentTimeMillis()}"
        val meta=JSONObject().apply{put("name",name);put("mimeType",mime)}
        val conn=URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
            .openConnection() as HttpURLConnection
        conn.requestMethod="POST";conn.doOutput=true
        conn.setRequestProperty("Authorization","Bearer $token")
        conn.setRequestProperty("Content-Type","multipart/related; boundary=$boundary")
        DataOutputStream(conn.outputStream).use { out ->
            out.writeBytes("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n")
            out.write(meta.toString().toByteArray())
            out.writeBytes("\r\n--$boundary\r\nContent-Type: $mime\r\n\r\n")
            out.write(data);out.writeBytes("\r\n--$boundary--\r\n")
        }
        if(conn.responseCode !in 200..299) throw IOException("Drive upload failed: ${conn.responseCode}")
        conn.disconnect()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashHisabApp(context: Context,onConnectDrive:()->Unit) {
    val store=remember{LocalStore(context)}
    var accounts by remember{mutableStateOf(store.accounts())}
    var tx by remember{mutableStateOf(store.transactions())}
    var tab by remember{mutableIntStateOf(0)}
    var dialog by remember{mutableStateOf<String?>(null)}
    var previewFile by remember{mutableStateOf<File?>(null)}
    val connected=context.getSharedPreferences("cash_hisab",Context.MODE_PRIVATE).getBoolean("drive_connected",false)

    MaterialTheme {
        Scaffold(
            topBar={CenterAlignedTopAppBar(
                title={Text("Cash হিসাব",fontWeight=FontWeight.Bold)},
                actions={
                    IconButton(onClick={dialog="accounts"}){Icon(Icons.Default.AccountBalanceWallet,null)}
                    IconButton(onClick={onConnectDrive}){Icon(Icons.Default.CloudUpload,null)}
                    IconButton(onClick={onConnectDrive}){Icon(Icons.Default.Sync,null)}
                    
                }
            )},
            bottomBar={NavigationBar{
                NavigationBarItem(tab==0,{tab=0},icon={Icon(Icons.Default.Home,null)},label={Text("হোম")})
                NavigationBarItem(tab==1,{tab=1},icon={Icon(Icons.Default.List,null)},label={Text("লেনদেন")})
                NavigationBarItem(tab==2,{tab=2},icon={Icon(Icons.Default.Assessment,null)},label={Text("রিপোর্ট")})
            }},
            floatingActionButton={FloatingActionButton(onClick={dialog="add"}){Icon(Icons.Default.Add,null)}}
        ){pad->
            when(tab){
                0->HomeScreen(Modifier.padding(pad),tx,accounts){dialog="add"}
                1->HistoryScreen(Modifier.padding(pad),tx,
                    onDelete={id -> tx = tx.filterNot { it.id == id }; store.saveTransactions(tx)},
                    onEdit={id -> dialog="edit:$id"})
                else->ReportScreen(Modifier.padding(pad),tx,accounts,
                    onGenerate={files-> previewFile=files.firstOrNull() },
                    onPreview={previewFile=it},
                    onConnectDrive=onConnectDrive,
                    driveConnected=connected,
                    onTransfer={dialog="transfer"})
            }
        }
        if(dialog=="transfer") TransferDialog(accounts,{dialog=null}){amount,from,to,note->
            val id=System.currentTimeMillis()
            val now=System.currentTimeMillis()
            val out=Transaction(id,TxType.EXPENSE,amount,"Transfer → $to",from,note,now,id)
            val inn=Transaction(id+1,TxType.INCOME,amount,"Transfer ← $from",to,note,now,id)
            tx=listOf(out,inn)+tx;store.saveTransactions(tx);dialog=null
        }
        if(dialog=="add") AddTransactionDialog(accounts,{dialog=null}){type,amount,cat,acc,note->
            val n=listOf(Transaction(System.currentTimeMillis(),type,amount,cat,acc,note,System.currentTimeMillis()))+tx
            tx=n;store.saveTransactions(n);dialog=null
        }
        if(dialog=="accounts") AccountManagerDialog(accounts,{dialog=null}){name->
            if(name.isNotBlank()&&!accounts.any{it.equals(name.trim(),true)}){
                accounts=accounts+name.trim();store.saveAccounts(accounts)
            }
        }
        
        if (dialog?.startsWith("edit:") == true) {
            val id = dialog!!.substringAfter(":").toLongOrNull()
            val old = tx.firstOrNull { it.id == id }
            if (old != null) {
                EditTransactionDialog(
                    old = old,
                    accounts = accounts,
                    onDismiss = { dialog = null },
                    onSave = { updated ->
                        tx = tx.map { if (it.id == updated.id) updated else it }
                        store.saveTransactions(tx)
                        dialog = null
                    }
                )
            }
        }

        previewFile?.let{PdfPreviewDialog(it){previewFile=null}}
    }
}

@Composable
fun HomeScreen(modifier:Modifier,tx:List<Transaction>,accounts:List<String>,onAdd:()->Unit){
    val income=tx.filter{it.type==TxType.INCOME}.sumOf{it.amount};val expense=tx.filter{it.type==TxType.EXPENSE}.sumOf{it.amount}
    LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("বর্তমান ব্যালান্স");Text("৳ ${money(income-expense)}",fontSize=30.sp,fontWeight=FontWeight.Bold)}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            SummaryCard("মোট আয়",income,Modifier.weight(1f));SummaryCard("মোট ব্যয়",expense,Modifier.weight(1f))}}
        item{Text("হিসাবের ধরন",fontSize=20.sp,fontWeight=FontWeight.Bold)}
        items(accounts){a->val bal=tx.filter{it.account==a}.sumOf{if(it.type==TxType.INCOME)it.amount else -it.amount}
            ListItem(headlineContent={Text(a)},trailingContent={Text("৳ ${money(bal)}")})}
        item{Text("সাম্প্রতিক লেনদেন",fontSize=20.sp,fontWeight=FontWeight.Bold)}
        if(tx.isEmpty())item{Button(onClick=onAdd){Text("প্রথম লেনদেন যোগ করুন")}}else items(tx.take(8),key={it.id}){TransactionRow(it)}
    }
}
@Composable fun SummaryCard(t:String,a:Double,m:Modifier){Card(m){Column(Modifier.padding(14.dp)){Text(t);Text("৳ ${money(a)}",fontWeight=FontWeight.Bold,fontSize=19.sp)}}}

@Composable
fun HistoryScreen(
    m: Modifier,
    tx: List<Transaction>,
    onDelete: (Long) -> Unit,
    onEdit: (Long) -> Unit
) {
    if (tx.isEmpty()) {
        Box(m.fillMaxSize(), contentAlignment = Alignment.Center) { Text("কোনো লেনদেন নেই") }
    } else {
        LazyColumn(
            m.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("সব লেনদেন", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            items(tx, key = { it.id }) {
                TransactionRow(it, onEdit = { onEdit(it.id) }, onDelete = { onDelete(it.id) })
            }
        }
    }
}

@Composable
fun TransactionRow(
    t: Transaction,
    onEdit: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (t.type == TxType.INCOME) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                null
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.category, fontWeight = FontWeight.SemiBold)
                Text("${t.account} • ${t.note.ifBlank { "কোনো নোট নেই" }}", fontSize = 12.sp)
                Text(dateText(t.time), fontSize = 11.sp)
            }
            Text(
                "${if (t.type == TxType.INCOME) "+" else "-"} ৳${money(t.amount)}",
                fontWeight = FontWeight.Bold
            )
            if (onEdit != null) {
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit") }
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
            }
        }
    }
}

@Composable
fun ReportScreen(m:Modifier,tx:List<Transaction>,accounts:List<String>,onGenerate:(List<File>)->Unit,onPreview:(File)->Unit,onConnectDrive:()->Unit,driveConnected:Boolean,onTransfer:()->Unit){
    val context=LocalContext.current
    Column(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("রিপোর্ট ও PDF",fontSize=24.sp,fontWeight=FontWeight.Bold)
        Button(onClick=onTransfer, modifier=Modifier.fillMaxWidth()) {
            Icon(Icons.Default.SwapHoriz,null); Spacer(Modifier.width(6.dp)); Text("Account Transfer")
        }
        Text(if(driveConnected)"Google Drive: Connected" else "Google Drive: Not connected")
        Button(onClick=onConnectDrive,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(6.dp));Text("Google Drive Backup Connect")}
        Button(onClick={onGenerate(PdfReports.createAll(context,LocalStore(context)))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(6.dp));Text("Full Report PDF তৈরি")}
        accounts.forEach{a->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val f=PdfReports.createPdf(File(context.filesDir,"reports/account_${a.replace(Regex("[^A-Za-z0-9_-]"),"_")}.pdf"),"Account: $a",tx.filter{it.account==a})
                    onPreview(f)
                }){Text("$a PDF Preview")}
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val f=PdfReports.createPdf(File(context.filesDir,"reports/account_${a.replace(Regex("[^A-Za-z0-9_-]"),"_")}.pdf"),"Account: $a",tx.filter{it.account==a})
                    shareFile(context,f)
                }){Text("Download/Share")}
            }
        }
        Text("রাত ১২টার কাছাকাছি প্রতিদিন একটি scheduled backup চালানো হবে। Android-এর battery/network optimization-এর কারণে একদম 12:00:00-এ চালানোর নিশ্চয়তা নেই।",fontSize=12.sp)
        Text("পরবর্তী ধাপে: Transfer, Edit/Delete, Budget, Due/Customer এবং Monthly Report আরও উন্নত করা হবে।",fontSize=12.sp)
    }
}

@Composable fun PdfPreviewDialog(file:File,onClose:()->Unit){
    var bitmap by remember{mutableStateOf<Bitmap?>(null)}
    LaunchedEffect(file){bitmap=renderFirstPage(file)}
    AlertDialog(onDismissRequest=onClose,title={Text(file.name)},text={
        Column(horizontalAlignment=Alignment.CenterHorizontally){
            bitmap?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxWidth())}?:Text("PDF preview তৈরি হচ্ছে…")
        }
    },confirmButton={TextButton(onClick={shareFile(LocalContext.current,file)}){Text("Download/Share")}},dismissButton={TextButton(onClick=onClose){Text("বন্ধ")}})
}

fun renderFirstPage(file:File):Bitmap?=runCatching{
    ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY).use{pfd->
        PdfRenderer(pfd).use{r->r.openPage(0).let{page->
            val b=Bitmap.createBitmap(page.width,page.height,Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE);page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);page.close();b
        }}
    }
}.getOrNull()

fun shareFile(context:Context,file:File){
    val uri=FileProvider.getUriForFile(context,context.packageName+".provider",file)
    context.startActivity(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddTransactionDialog(accounts:List<String>,dismiss:()->Unit,save:(TxType,Double,String,String,String)->Unit){
    var type by remember{mutableStateOf(TxType.INCOME)};var amount by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var acc by remember{mutableStateOf(accounts.firstOrNull()?:"Cash")};var note by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=dismiss,title={Text("নতুন লেনদেন")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(type==TxType.INCOME,{type=TxType.INCOME},label={Text("আয়")});FilterChip(type==TxType.EXPENSE,{type=TxType.EXPENSE},label={Text("ব্যয়")})}
        OutlinedTextField(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},label={Text("টাকার পরিমাণ")})
        OutlinedTextField(cat,{cat=it},label={Text("ক্যাটাগরি")});Text("Account")
        LazyColumn(Modifier.heightIn(max=130.dp)){items(accounts){a->FilterChip(acc==a,{acc=a},label={Text(a)})}}
        OutlinedTextField(note,{note=it},label={Text("নোট")})
    }},confirmButton={Button(enabled=amount.toDoubleOrNull()?.let{it>0}==true&&cat.isNotBlank(),onClick={save(type,amount.toDouble(),cat.trim(),acc,note.trim())}){Text("সেভ")}},dismissButton={TextButton(onClick=dismiss){Text("বাতিল")}})
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AccountManagerDialog(accounts:List<String>,dismiss:()->Unit,add:(String)->Unit){
    var n by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=dismiss,title={Text("Account / হিসাব")},text={Column{Text("নিজের প্রয়োজনমতো নতুন অপশন যোগ কর।");accounts.forEach{ListItem(headlineContent={Text(it)})};OutlinedTextField(n,{n=it},label={Text("নতুন অপশন")});Button(onClick={add(n);n=""},enabled=n.isNotBlank()){Text("➕ যোগ করুন")}}},confirmButton={TextButton(onClick=dismiss){Text("সম্পন্ন")}})
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTransactionDialog(
    old: Transaction,
    accounts: List<String>,
    onDismiss: () -> Unit,
    onSave: (Transaction) -> Unit
) {
    var type by remember { mutableStateOf(old.type) }
    var amount by remember { mutableStateOf(old.amount.toString()) }
    var cat by remember { mutableStateOf(old.category) }
    var acc by remember { mutableStateOf(old.account) }
    var note by remember { mutableStateOf(old.note) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("লেনদেন Edit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(type == TxType.INCOME, { type = TxType.INCOME }, label = { Text("আয়") })
                    FilterChip(type == TxType.EXPENSE, { type = TxType.EXPENSE }, label = { Text("ব্যয়") })
                }
                OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("পরিমাণ") })
                OutlinedTextField(cat, { cat = it }, label = { Text("ক্যাটাগরি") })
                Text("Account")
                LazyColumn(Modifier.heightIn(max = 120.dp)) {
                    items(accounts) { a -> FilterChip(acc == a, { acc = a }, label = { Text(a) }) }
                }
                OutlinedTextField(note, { note = it }, label = { Text("নোট") })
            }
        },
        confirmButton = {
            Button(
                enabled = amount.toDoubleOrNull()?.let { it > 0 } == true && cat.isNotBlank(),
                onClick = {
                    onSave(old.copy(
                        type = type,
                        amount = amount.toDouble(),
                        category = cat.trim(),
                        account = acc,
                        note = note.trim()
                    ))
                }
            ) { Text("আপডেট") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferDialog(accounts: List<String>, dismiss: () -> Unit, transfer: (Double,String,String,String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var from by remember { mutableStateOf(accounts.firstOrNull() ?: "Cash") }
    var to by remember { mutableStateOf(accounts.getOrNull(1) ?: accounts.firstOrNull() ?: "Cash") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("Account Transfer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("পরিমাণ") })
                Text("From: $from")
                LazyColumn(Modifier.heightIn(max = 100.dp)) {
                    items(accounts) { a -> FilterChip(from == a, { from = a }, label = { Text(a) }) }
                }
                Text("To: $to")
                LazyColumn(Modifier.heightIn(max = 100.dp)) {
                    items(accounts) { a -> FilterChip(to == a, { to = a }, label = { Text(a) }) }
                }
                OutlinedTextField(note, { note = it }, label = { Text("নোট") })
            }
        },
        confirmButton = {
            Button(
                enabled = amount.toDoubleOrNull()?.let { it > 0 } == true && from != to,
                onClick = { transfer(amount.toDouble(), from, to, note); dismiss() }
            ) { Text("Transfer") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("বাতিল") } }
    )
}

fun money(v:Double)=String.format(Locale.US,"%.2f",v)
fun dateText(t:Long)=SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(t))
